package org.ahmed.spring_cloud_security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
